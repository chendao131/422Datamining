package k_medians;
import makedata.src.mdata.*;

import java.util.LinkedList;
import java.io.*;
public class KOutput {
	
	public static void createMatFile(LinkedList<point> d, point[] cl, point[] ce, String path) throws IOException{
//		PrintWriter pw = new PrintWriter(new FileWriter("test.txt"));
//		pw.write("test");
		FileWriter ryt[] = new FileWriter[ce.length];
		BufferedWriter out[] = new BufferedWriter[ce.length];
		int counter[] = new int[ce.length];
		for(int i=0;i<ce.length;i++){		
			ryt[i]=new FileWriter(path+"cluster"+i+".txt");
			out[i]=new BufferedWriter(ryt[i]);
			for(int j=0;j<d.size();j++){
				if(ce[i].x==cl[j].x&&ce[i].y==cl[j].y){
					counter[i]++;
					Double x = d.get(j).x;
					Double y = d.get(j).y;
					String temp = ""+x.intValue()+","+y.intValue();
					out[i].write(temp+"\n");
				}
			}
			Double x = ce[i].x;
			Double y = ce[i].y;
			out[i].write(""+x.intValue()+","+y.intValue());
			out[i].close();
			System.out.println(counter[i]);
		}
/*		FileWriter ryt = new FileWriter("fuck.txt");
		BufferedWriter out = new BufferedWriter(ryt);
		out.write("fuck");
		out.close();*/
	}
	public static void main(String args[]) throws IOException{
		LinkedList<point> temp = getdata.getdataset();
		sample ss = new sample();
		LinkedList<point> output = ss.sampling(temp, 3, 0.35);
    	int weight[] = new int[20000];
    	for(int i=0; i<20000; i++){
    		//Double t = Math.random()*temp.size();
    		weight[i] =1;
    	}
    	
		KMediansLloyd kld0 = new KMediansLloyd(3,temp, weight);
		KMediansLloyd kld1 = new KMediansLloyd(3,output, weight);
		point[] cl = kld0.getClusters();
		point[] ce = kld0.getCenters();
		KOutput.createMatFile(temp, cl, ce,"/Users/lishuai/Documents/workspace/MapReduce/data/");
		cl = kld1.getClusters();
		ce = kld1.getCenters();
		KOutput.createMatFile(output, cl, ce,"/Users/lishuai/Documents/workspace/MapReduce/dataS/");
		for(int i=0;i<ce.length;i++)
			System.out.println(""+ce[i].x+","+ce[i].y);
	}
}
