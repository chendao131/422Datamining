package k_medians;
import k_center.KCenter;

import java.util.Collections;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Comparator;
import java.io.*;

import makedata.src.mdata.getdata;
import makedata.src.mdata.point;

public class KMediansLloyd{
	private int[] weight;
	private LinkedList<point> dataset;
	private point[] cluster;
	private point[] centers;
	private int k;
	private double[] dist;
	private int[] clusterCate;
	private boolean clustered;
	
	private class CompareW implements Comparator<WghMap>{
		public int compare(WghMap a, WghMap b){
			if(a.weight()>b.weight())
				return 1;
			else if(a.weight()<b.weight())
				return -1;
			else 
				return 0;
		}
		public boolean equals(Object c){
			if(c instanceof CompareW)
				return true;
			else
				return false;
		}
	}
	private class CompareX implements Comparator<WghMap>{
		public int compare(WghMap a, WghMap b) {
			if(dataset.get(a.index()).x*a.weight()>dataset.get(b.index()).x*b.weight())
				return 1;
			else if(dataset.get(a.index()).x*a.weight()<dataset.get(b.index()).x*b.weight())
				return -1;
			else 
				return 0;
		}
		public boolean equals(Object c){
			if(c instanceof CompareW)
				return true;
			else
				return false;
		}	
	}
	private class CompareY implements Comparator<WghMap>{
		public int compare(WghMap a, WghMap b) {
			if(dataset.get(a.index()).y*a.weight()>dataset.get(b.index()).y*b.weight())
				return 1;
			else if(dataset.get(a.index()).x*a.weight()<dataset.get(b.index()).y*b.weight())
				return -1;
			else 
				return 0;
		}
		public boolean equals(Object c){
			if(c instanceof CompareY)
				return true;
			else
				return false;
		}	
	}
	
    public KMediansLloyd( int newK, LinkedList<point> newSet,int[] newWeight){
    	dataset = newSet;
    	k = newK;
    	cluster = new point[dataset.size()];
    	clusterCate = new int[dataset.size()];
    	centers = new point[k];
    	dist = new double[dataset.size()];
    	weight = newWeight;
    	clustered = false;
    }
    public point[] getClusters(){
    	boolean notDone = false;
   		pickKCenters();
    	do{
    		clustering();
    		notDone = reCenter();
    	}while(notDone);
    	clustered = true;
    	return cluster;
    }
    public point[] getCenters(){
    	if(clustered)
    		return centers;
    	else
    		return null;
    }
    private void pickKCenters(){
    	for(int i=0;i<k;i++){
    		Double temp = Math.random()*dataset.size();
    	//	System.out.println(temp);
   			centers[i] = dataset.get(temp.intValue());
    	//	System.out.println(centers[i]);
    	}
    }
    private boolean clustering(){
    	boolean notDone = false;
    	for(int i=0; i<dataset.size(); i++){
    		int minIndex = 0;
    		double minDist = Double.MAX_VALUE;
    		for(int j=0; j<k; j++){
    			double tempDist = length(centers[j],dataset.get(i));
    			//System.out.println(tempDist + " "+i+", "+centers[j]);
    			if(minDist>tempDist){
    				minDist = tempDist;
    				minIndex = j;
    			}
    		}
    		dist[i] = minDist;
    		cluster[i] = centers[minIndex];
    		//if(minIndex!=clusterCate[i])
    		//	notDone = true;
    		clusterCate[i] = minIndex;
//    		System.out.println();
    	}
    	return notDone;
    }
    private boolean reCenter(){
    	boolean notDone = false;
    	for(int i=0; i<k; i++){
    		ArrayList<WghMap> tempCluster = new ArrayList<WghMap>();
    		for(int j=0; j<dataset.size(); j++){
    			if(cluster[j] == centers[i]){
    				WghMap wm = new WghMap(j, weight[j]);
    				tempCluster.add(new WghMap(j, weight[j]));
    //				System.out.println(wm.index()+", " + wm.weight());
    			}
    		}
    		Collections.sort(tempCluster, new CompareX());
    		double tempX = dataset.get(tempCluster.get(tempCluster.size()/2+1).index()).x;
    		Collections.sort(tempCluster, new CompareY());
    		double tempY= dataset.get(tempCluster.get(tempCluster.size()/2+1).index()).y;
    		System.out.println("old: "+ centers[i].x+","+centers[i].y);
    		if(centers[i].x!=tempX||centers[i].y!=tempY)
    			notDone = true;
   			centers[i] = new point(tempX, tempY);
    		System.out.println("new: "+ centers[i].x+","+centers[i].y);
    	}
    	System.out.println();
    	return notDone;
    }
    private double length(point center, point p){
    	double temp1 = p.x-center.x;
		double temp2 = p.y-center.y;
		return Math.sqrt((temp1*temp1)+(temp2*temp2));
    }
    public static void main(String args[]) throws IOException{
    	LinkedList<point> temp = getdata.getdataset();
    	int weight[] = new int[1000];
    	for(int i=0; i<1000; i++){
    		//Double t = Math.random()*temp.size();
    		weight[i] =1; 
    	}
		KMediansLloyd kld = new KMediansLloyd(2,temp, weight);
		kld.getClusters();
	//	kld.pickKCenters();
	//	kld.clustering();
		//for(int i=0; i<temp.size(); i++)
	//		System.out.println(kld.cluster[i]);
	//	System.out.println();
	//	for(int i=0; i<2; i++)
	//		System.out.println(kld.centers[i]);
	//	for(int i=0;i<kld.cluster.length;i++)
	//		System.out.println("point"+i +" " + temp.get(i).x+","+temp.get(i).y + ": " + (kld.cluster[i]).x+","+kld.cluster[i].y);
    }
}
