package k_medians;

public class KMediansLS {
	
}
