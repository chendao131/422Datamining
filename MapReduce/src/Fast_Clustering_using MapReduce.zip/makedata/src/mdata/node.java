package makedata.src.mdata;

public class node {
	node next;
	double dis;
}
