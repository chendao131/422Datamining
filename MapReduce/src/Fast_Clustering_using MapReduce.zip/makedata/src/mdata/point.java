package makedata.src.mdata;

public class point {
	public double x;
	public double y;
	
	public point(double xv, double yv){
		x = xv;
		y = yv;
	}
	public point(){
		
	}
}
